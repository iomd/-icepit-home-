# [icepit-home]
This folder is the root of all operations.
Setup Aliases & Symlinks to all important locations in all Directories.

## Todo
- [ ]find icons for blue folders
- [ ]setup folder-action-workflow or script for sorting files dropped into folder. Maybe a type of reminder to sort files via reminders or calendar thru scripting or something.
- [ ]make a full how to for my folder structure